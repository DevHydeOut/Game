import { useState, useEffect } from 'react';
import { db } from '@/lib/firebase';
import {
  collection,
  getDocs,
  query,
  where,
} from 'firebase/firestore';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { FaSpinner } from 'react-icons/fa';
import { 
  SummaryItem, 
  EntryData, 
  getCurrentTimeSlot, 
  getActiveNumbers, 
  generateAllNumbers,
  getColorForAmount
} from './utils';

interface CurrentStatusProps {
  type: 'jodi' | 'single';
  setType: (type: 'jodi' | 'single') => void;
}

export default function CurrentStatus({ type, setType }: CurrentStatusProps) {
  const [currentTimeSlot, setCurrentTimeSlot] = useState(getCurrentTimeSlot());
  const [currentSlotSummary, setCurrentSlotSummary] = useState<SummaryItem[]>([]);
  const [fetchingCurrentSlot, setFetchingCurrentSlot] = useState(false);
  const [maxAmount, setMaxAmount] = useState(0);
  
  useEffect(() => {
    const newTimeSlot = getCurrentTimeSlot();
    setCurrentTimeSlot(newTimeSlot);
    fetchCurrentSlotData(newTimeSlot);
    
    const interval = setInterval(() => {
      const updatedTimeSlot = getCurrentTimeSlot();
      setCurrentTimeSlot(updatedTimeSlot);
      fetchCurrentSlotData(updatedTimeSlot);
    }, 60000);
    
    return () => clearInterval(interval);
  }, [type]);
  
  const fetchCurrentSlotData = async (slot: { startTime: Date; endTime: Date }) => {
    if (!slot) return;
    
    setFetchingCurrentSlot(true);
    
    try {
      const today = new Date().toISOString().split('T')[0];
      
      const q = query(
        collection(db, 'bets'),
        where('date', '==', today),
        where('type', '==', type),
        where('createdAt', '>=', slot.startTime),
        where('createdAt', '<', slot.endTime)
      );
      
      const snapshot = await getDocs(q);
      const allEntries = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data() as EntryData,
        createdAt: doc.data().createdAt.toDate()
      }));
      
      const numberMap = new Map<string, { total: number; users: Set<string> }>();
      
      // Initialize with all possible numbers
      generateAllNumbers(type).forEach(num => {
        numberMap.set(num, { total: 0, users: new Set() });
      });
      
      // Fill in data from entries
      allEntries.forEach(entry => {
        const number = entry.number;
        const userId = entry.userId || entry.id;
        
        if (!numberMap.has(number)) {
          numberMap.set(number, { total: 0, users: new Set() });
        }
        
        const data = numberMap.get(number)!;
        data.total += Number(entry.amount);
        data.users.add(userId);
      });
      
      const summaryItems = Array.from(numberMap.entries())
        .map(([number, info]) => ({
          number,
          total: info.total,
          userCount: info.users.size
        }));
      
      const maxTotal = Math.max(...summaryItems.map(item => item.total), 1);
      setMaxAmount(maxTotal);
      setCurrentSlotSummary(summaryItems);
    } catch (error) {
      console.error("Error fetching current slot data:", error);
    } finally {
      setFetchingCurrentSlot(false);
    }
  };

  return (
    <Card className="bg-white shadow-lg border-0">
      <div className="bg-gradient-to-r from-indigo-600 to-indigo-700 text-white p-4 rounded-t-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <span className="text-lg font-medium">Current Status</span>
            <select
              value={type}
              onChange={(e) => setType(e.target.value as 'jodi' | 'single')}
              className="bg-white text-indigo-700 border-0 rounded-md px-2 py-1 text-sm"
            >
              <option value="jodi">Jodi (01-99)</option>
              <option value="single">Single (1-9)</option>
            </select>
            <span className="text-white/80 text-sm">{currentTimeSlot?.formattedTimeRange}</span>
          </div>
          <Button 
            variant="outline" 
            onClick={() => currentTimeSlot && fetchCurrentSlotData(currentTimeSlot)}
            disabled={fetchingCurrentSlot}
            className="bg-white text-indigo-600 hover:bg-gray-100"
          >
            {fetchingCurrentSlot ? (
              <><FaSpinner className="animate-spin mr-2" /> Refreshing</>
            ) : 'Refresh'}
          </Button>
        </div>
      </div>
      <CardContent className="p-0">
        {fetchingCurrentSlot ? (
          <div className="flex justify-center items-center py-12">
            <FaSpinner className="animate-spin text-indigo-600 text-2xl" />
          </div>
        ) : (
          <div className="p-4">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              {/* Active Numbers Column - numbers with bets */}
              <Card className="border border-gray-200">
                <div className="bg-green-50 p-3 border-b border-green-100">
                  <div className="text-base font-medium text-green-700">Active Numbers</div>
                </div>
                <CardContent className="p-0 max-h-[400px] overflow-y-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50 sticky top-0">
                      <tr>
                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Number</th>
                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Users</th>
                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount (₹)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {getActiveNumbers(currentSlotSummary).length > 0 ? (
                        getActiveNumbers(currentSlotSummary)
                          .sort((a, b) => b.total - a.total)
                          .map((item) => (
                          <tr key={item.number} className="hover:bg-gray-50">
                            <td className="px-4 py-3 font-medium">{item.number}</td>
                            <td className="px-4 py-3">{item.userCount}</td>
                            <td className="px-4 py-3 text-green-600 font-medium">{item.total}</td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={3} className="px-4 py-3 text-center text-gray-500">No active numbers</td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </CardContent>
              </Card>
              
              {/* All Numbers - Displays all possible numbers with their data */}
              <Card className="border border-gray-200 col-span-1 lg:col-span-2">
                <div className="bg-blue-50 p-3 border-b border-blue-100">
                  <div className="text-base font-medium text-blue-700">All Numbers ({type === 'jodi' ? '01-99' : '1-9'})</div>
                </div>
                <CardContent className="p-4 max-h-[400px] overflow-y-auto">
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
                    {currentSlotSummary.map((item) => (
                      <div 
                        key={item.number}
                        className={`p-3 border rounded-lg flex flex-col items-center justify-center transition-all ${
                          getColorForAmount(item.total, maxAmount)
                        }`}
                      >
                        <span className="font-medium text-lg">{item.number}</span>
                        <div className="flex flex-col items-center">
                          <span className="text-sm font-medium">{item.userCount} user{item.userCount !== 1 ? 's' : ''}</span>
                          <span className={`font-medium ${item.total > 0 ? 'text-green-600' : 'text-gray-500'}`}>
                            ₹{item.total}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}