import { useState, useEffect } from 'react';
import { db } from '@/lib/firebase';
import {
  collection,
  addDoc,
  getDocs,
  query,
  where,
  Timestamp
} from 'firebase/firestore';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { FaSpinner, FaCalendarAlt, FaChartLine } from 'react-icons/fa';
import { EntryData, getCurrentTimeSlot } from './utils';

interface EntryFormProps {
  type: 'jodi' | 'single';
  setType: (type: 'jodi' | 'single') => void;
}

export default function EntryForm({ type, setType }: EntryFormProps) {
  const [number, setNumber] = useState('');
  const [amount, setAmount] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [loading, setLoading] = useState(false);
  const [pendingEntries, setPendingEntries] = useState<EntryData[]>([]);
  const [currentTimeSlot, setCurrentTimeSlot] = useState(getCurrentTimeSlot());

  useEffect(() => {
    fetchPendingEntries();
    
    const interval = setInterval(() => {
      setCurrentTimeSlot(getCurrentTimeSlot());
    }, 60000);
    
    return () => clearInterval(interval);
  }, [date, type]);

  const fetchPendingEntries = async () => {
    try {
      const q = query(
        collection(db, 'bets'),
        where('date', '==', date),
        where('type', '==', type),
        where('pending', '==', true)
      );
      
      const snapshot = await getDocs(q);
      const entries = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data() as EntryData,
        createdAt: doc.data().createdAt.toDate()
      }));
      
      setPendingEntries(entries);
    } catch (error) {
      console.error("Error fetching pending entries:", error);
    }
  };

  const handleSubmit = async () => {
    if (type === 'single' && !/^[1-9]$/.test(number)) {
      alert('Enter a single number from 1 to 9 without leading zero');
      return;
    }

    if (type === 'jodi' && (!/^[0-9]{2}$/.test(number) || Number(number) < 1 || Number(number) > 99)) {
      alert('Enter a jodi number from 01 to 99 with leading zero if < 10');
      return;
    }

    if (!amount || isNaN(Number(amount)) || Number(amount) <= 0) {
      alert('Enter a valid amount');
      return;
    }

    try {
      setLoading(true);
      await addDoc(collection(db, 'bets'), {
        number,
        amount: Number(amount),
        type,
        date,
        createdAt: Timestamp.now(),
        pending: true
      });
      
      alert('Entry saved and will display at next 15-minute interval');
      setNumber('');
      setAmount('');
      fetchPendingEntries();
    } catch (error) {
      console.error('Error saving entry:', error);
      alert('Error saving entry');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Entry Form */}
      <Card className="bg-white shadow-lg border-0">
        <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white p-4 rounded-t-lg">
          <div className="flex items-center text-lg font-medium">
            <FaChartLine className="mr-2" /> New Entry
          </div>
        </div>
        <CardContent className="grid gap-5 p-6">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block mb-2 font-medium text-gray-700">Entry Type</label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value as 'jodi' | 'single')}
                className="w-full border border-gray-300 rounded-lg px-4 py-3 bg-white shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="jodi">Jodi (01-99)</option>
                <option value="single">Single (1-9)</option>
              </select>
            </div>
            <div>
              <label className="block mb-2 font-medium text-gray-700">Date</label>
              <div className="relative">
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-4 py-3 bg-white shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
                <FaCalendarAlt className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              </div>
            </div>
          </div>

          <div>
            <label className="block mb-2 font-medium text-gray-700">
              Number {type === 'jodi' ? '(01-99)' : '(1-9)'}
            </label>
            <Input
              type="text"
              placeholder={type === 'jodi' ? "Enter jodi number (e.g. 07)" : "Enter single number (e.g. 7)"}
              value={number}
              onChange={(e) => setNumber(e.target.value)}
              className="w-full px-4 py-3 text-lg"
            />
          </div>

          <div>
            <label className="block mb-2 font-medium text-gray-700">Amount (₹)</label>
            <Input
              type="number"
              placeholder="Enter amount (e.g. 100)"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="w-full px-4 py-3 text-lg"
            />
          </div>

          <Button 
            onClick={handleSubmit} 
            disabled={loading} 
            className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-medium py-3 text-lg mt-2 transition-all"
          >
            {loading ? (
              <><FaSpinner className="animate-spin mr-2" /> Saving Entry...</>
            ) : 'Save Entry'}
          </Button>
        </CardContent>
      </Card>

      {/* Pending Entries */}
      <Card className="bg-white shadow-lg border-0">
        <div className="bg-gradient-to-r from-amber-500 to-amber-600 text-white p-4 rounded-t-lg">
          <div className="flex items-center justify-between text-lg font-medium">
            <span>Pending Entries</span>
            {currentTimeSlot && (
              <span className="text-sm font-normal">
                Will display at {currentTimeSlot.endTime.toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'})}
              </span>
            )}
          </div>
        </div>
        <CardContent className="p-0">
          {pendingEntries.length > 0 ? (
            <div className="divide-y divide-gray-100 max-h-[400px] overflow-y-auto">
              {pendingEntries.map((entry) => (
                <div key={entry.id} className="grid grid-cols-3 px-6 py-4">
                  <span className="font-medium text-lg">{entry.number}</span>
                  <span className="text-green-600 font-medium">₹{entry.amount}</span>
                  <span className="text-gray-500">
                    {entry.createdAt.toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'})}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex items-center justify-center py-12 text-gray-500">
              <p className="text-center">No pending entries</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}