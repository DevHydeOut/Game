import { DocumentData, Timestamp } from 'firebase/firestore';

export interface SummaryItem {
  number: string;
  total: number;
  userCount: number;
  minAmount?: number;
}

export interface TimeSlot {
  startTime: Date;
  endTime: Date;
  formattedTimeRange: string;
  entries: SummaryItem[];
  isCurrent?: boolean;
}

export interface EntryData extends DocumentData {
  id?: string;
  number: string;
  amount: number;
  userId?: string;
  createdAt: Date;
  date: string;
  type: 'jodi' | 'single';
  pending?: boolean;
}

// Generate all possible numbers for jodi (01-99) or single (1-9)
export const generateAllNumbers = (type: 'jodi' | 'single') => {
  if (type === 'single') {
    return Array.from({ length: 9 }, (_, i) => String(i + 1));
  } else {
    return Array.from({ length: 99 }, (_, i) => {
      const num = i + 1;
      return num < 10 ? `0${num}` : String(num);
    });
  }
};

// Get all time slots for a day in 15-minute intervals
export const getTimeSlotBoundaries = (dateStr: string) => {
  const slots: { start: Date; end: Date; formatted: string }[] = [];
  const baseDate = new Date(dateStr);
  baseDate.setHours(0, 0, 0, 0);
  
  for (let hour = 0; hour < 24; hour++) {
    for (let minute = 0; minute < 60; minute += 15) {
      const start = new Date(baseDate);
      start.setHours(hour, minute, 0, 0);
      
      const end = new Date(start);
      end.setMinutes(minute + 15);
      
      const formattedStart = start.toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit'
      });
      
      const formattedEnd = end.toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit'
      });
      
      const formatted = `${formattedStart} - ${formattedEnd}`;
      
      slots.push({ start, end, formatted });
    }
  }
  
  return slots.sort((a, b) => b.start.getTime() - a.start.getTime());
};

// Get current time slot (15-minute interval)
export const getCurrentTimeSlot = (): TimeSlot => {
  const now = new Date();
  const minutes = now.getMinutes();
  const slotStart = new Date(now);
  const slotEnd = new Date(now);
  
  const roundedMinutes = Math.floor(minutes / 15) * 15;
  slotStart.setMinutes(roundedMinutes, 0, 0);
  slotEnd.setMinutes(roundedMinutes + 15, 0, 0);
  
  const formattedStart = slotStart.toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit'
  });
  
  const formattedEnd = slotEnd.toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit'
  });
  
  return {
    startTime: slotStart,
    endTime: slotEnd,
    formattedTimeRange: `${formattedStart} - ${formattedEnd}`,
    entries: [],
    isCurrent: true
  };
};

// Filter active numbers - numbers with bets placed
export const getActiveNumbers = (items: SummaryItem[]) => {
  return items.filter(item => item.total > 0);
};

// Function to get color based on retention value for UI
export const getColorForAmount = (amount: number, maxAmount: number) => {
  if (amount === 0) return 'bg-gray-50 border-gray-200 text-gray-500';
  const intensity = Math.min(0.9, amount / maxAmount);
  if (intensity > 0.7) return 'bg-blue-100 border-blue-300 text-blue-800';
  if (intensity > 0.4) return 'bg-blue-50 border-blue-200 text-blue-700';
  return 'bg-blue-50/50 border-blue-100 text-blue-600';
};