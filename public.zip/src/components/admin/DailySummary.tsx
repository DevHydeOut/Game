'use client';

import { useEffect, useState } from 'react';
import { db } from '@/lib/firebase';
import { collection, getDocs, query, where, DocumentData } from 'firebase/firestore';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { FaSpinner, FaCalendarAlt } from 'react-icons/fa';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';

interface SummaryItem {
  number: string;
  total: number;
  userCount: number;
  minAmount?: number;
}

interface EntryData extends DocumentData {
  id?: string;
  number: string;
  amount: number;
  userId?: string;
  createdAt: Date;
  date: string;
  type: 'jodi' | 'single';
  pending?: boolean;
}

// Generate all possible numbers for jodi (01-99) or single (1-9)
const generateAllNumbers = (type: 'jodi' | 'single') => {
  if (type === 'single') {
    return Array.from({ length: 9 }, (_, i) => String(i + 1));
  } else {
    return Array.from({ length: 99 }, (_, i) => {
      const num = i + 1;
      return num < 10 ? `0${num}` : String(num);
    });
  }
};

const DailySummary = ({ setType, selectedDate, setSelectedDate }: DailySummaryProps) => {
  const [type, setLocalType] = useState<'jodi' | 'single'>('jodi');
  const [loading, setLoading] = useState(false);
  const [dailySummary, setDailySummary] = useState<SummaryItem[]>([]);
  const [today] = useState(new Date().toISOString().split('T')[0]);

  const fetchSummary = async (fetchDate = selectedDate, fetchType = type) => {
    setLoading(true);
    
    try {
      const q = query(
        collection(db, 'bets'),
        where('date', '==', fetchDate),
        where('type', '==', fetchType),
        where('pending', '==', false)
      );

      const snapshot = await getDocs(q);
      const numberMap = new Map<string, { total: number; users: Set<string>; minAmount: number }>();
      
      // Initialize with all possible numbers
      generateAllNumbers(fetchType).forEach(num => {
        numberMap.set(num, { total: 0, users: new Set(), minAmount: Infinity });
      });

      snapshot.forEach((doc) => {
        const data = doc.data() as EntryData;
        const userId = data.userId || doc.id;
        const key = data.number;

        if (!numberMap.has(key)) {
          numberMap.set(key, { total: 0, users: new Set(), minAmount: Infinity });
        }

        const entry = numberMap.get(key)!;
        entry.total += Number(data.amount);
        entry.users.add(userId);
        if (Number(data.amount) > 0) {
          entry.minAmount = Math.min(entry.minAmount, Number(data.amount));
        }
      });

      const result = Array.from(numberMap.entries())
        .map(([number, info]) => ({
          number,
          total: info.total,
          userCount: info.users.size,
          minAmount: info.minAmount !== Infinity ? info.minAmount : 0
        }));

      setDailySummary(result);
    } catch (error) {
      console.error("Error fetching summary:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    setType(type);
  }, [type, setType]);

  // Filter active numbers - numbers with bets placed
  const getActiveNumbers = (items: SummaryItem[]) => {
    return items.filter(item => item.total > 0).sort((a, b) => b.total - a.total);
  };

  // Get all numbers (active and inactive)
  const getAllNumbers = (items: SummaryItem[]) => {
    // For 'single', we sort numerically
    if (type === 'single') {
      return items.sort((a, b) => Number(a.number) - Number(b.number));
    }
    // For 'jodi', we sort numerically but as strings to preserve leading zeros
    return items.sort((a, b) => a.number.localeCompare(b.number));
  };

  return (
    <Card className="bg-white shadow-lg border-0">
      <div className="bg-gradient-to-r from-green-600 to-teal-600 text-white rounded-t-lg pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="text-2xl font-bold">Daily Summary</div>
            <select
              value={type}
              onChange={(e) => setType(e.target.value as 'jodi' | 'single')}
              className="bg-white/20 backdrop-blur-sm text-white border border-white/30 rounded-md px-3 py-1 text-sm"
            >
              <option value="jodi">Jodi (01-99)</option>
              <option value="single">Single (1-9)</option>
            </select>
          </div>
          <div className="flex items-center gap-3">
            <div className="relative">
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="bg-white/20 backdrop-blur-sm text-white border border-white/30 rounded-md px-3 py-1 pr-8"
              />
              <FaCalendarAlt className="absolute right-2 top-1/2 transform -translate-y-1/2 text-white/70" />
            </div>
            <Button 
              variant="outline" 
              onClick={() => fetchSummary()}
              disabled={loading}
              className="bg-white/20 backdrop-blur-sm text-white border border-white/30 hover:bg-white/30"
            >
              {loading ? (
                <><FaSpinner className="animate-spin mr-2" /> Loading</>
              ) : 'Refresh'}
            </Button>
          </div>
        </div>
        <div className="text-sm text-white/80 mt-1">
          {selectedDate === today ? 'Today\'s' : new Date(selectedDate).toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })} summary for {type === 'jodi' ? 'Jodi numbers' : 'Single numbers'}
        </div>
      </div>
      <CardContent className="p-0">
        {loading ? (
          <div className="flex justify-center items-center py-16">
            <FaSpinner className="animate-spin text-green-600 text-3xl" />
          </div>
        ) : (
          <Tabs defaultValue="active" className="p-6">
            <TabsList className="mb-6 bg-gray-100 p-1 rounded-lg">
              <TabsTrigger value="active" className="px-6 py-2">Active Numbers</TabsTrigger>
              <TabsTrigger value="all" className="px-6 py-2">All Numbers</TabsTrigger>
              <TabsTrigger value="grid" className="px-6 py-2">Grid View</TabsTrigger>
            </TabsList>
            
            <TabsContent value="active">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 py-3 text-left text-sm font-medium text-gray-500 uppercase tracking-wider">Number</th>
                      <th className="px-4 py-3 text-left text-sm font-medium text-gray-500 uppercase tracking-wider">Users</th>
                      <th className="px-4 py-3 text-left text-sm font-medium text-gray-500 uppercase tracking-wider">Amount (₹)</th>
                      <th className="px-4 py-3 text-left text-sm font-medium text-gray-500 uppercase tracking-wider">Min Bet (₹)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {getActiveNumbers(dailySummary).length > 0 ? (
                      getActiveNumbers(dailySummary).map((item) => (
                        <tr key={item.number} className="hover:bg-gray-50">
                          <td className="px-4 py-3 font-medium text-gray-900">{item.number}</td>
                          <td className="px-4 py-3">{item.userCount}</td>
                          <td className="px-4 py-3 text-green-600 font-medium">₹{item.total.toLocaleString()}</td>
                          <td className="px-4 py-3 text-gray-600">₹{item.minAmount ? item.minAmount.toLocaleString() : '0'}</td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={4} className="px-4 py-8 text-center text-gray-500">No active numbers for this date</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </TabsContent>
            
            <TabsContent value="all">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 py-3 text-left text-sm font-medium text-gray-500 uppercase tracking-wider">Number</th>
                      <th className="px-4 py-3 text-left text-sm font-medium text-gray-500 uppercase tracking-wider">Users</th>
                      <th className="px-4 py-3 text-left text-sm font-medium text-gray-500 uppercase tracking-wider">Amount (₹)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {getAllNumbers(dailySummary).map((item) => (
                      <tr key={item.number} className={`${item.total > 0 ? 'bg-green-50' : ''} hover:bg-gray-50`}>
                        <td className="px-4 py-2 font-medium text-gray-900">{item.number}</td>
                        <td className="px-4 py-2">{item.userCount}</td>
                        <td className={`px-4 py-2 ${item.total > 0 ? 'text-green-600 font-medium' : 'text-gray-400'}`}>
                          {item.total > 0 ? `₹${item.total.toLocaleString()}` : '₹0'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </TabsContent>
            
            <TabsContent value="grid">
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 lg:grid-cols-8 gap-3">
                {getAllNumbers(dailySummary).map((item) => (
                  <div 
                    key={item.number}
                    className={`p-3 border rounded-lg flex flex-col items-center justify-center ${
                      item.total > 0 ? 'bg-gradient-to-br from-green-50 to-teal-50 border-green-200' : 'bg-gray-50 border-gray-200'
                    }`}
                  >
                    <div className={`text-xl font-bold ${item.total > 0 ? 'text-gray-800' : 'text-gray-400'}`}>
                      {item.number}
                    </div>
                    <div className={`${item.total > 0 ? 'text-green-600 font-medium' : 'text-gray-400'}`}>
                      ₹{item.total > 0 ? item.total.toLocaleString() : '0'}
                    </div>
                    <div className="text-xs text-gray-500">
                      {item.userCount > 0 ? `${item.userCount} users` : 'No users'}
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        )}
      </CardContent>
    </Card>
  );
};

export default DailySummary;